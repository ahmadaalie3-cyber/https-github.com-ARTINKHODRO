package ir.artinkhodro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ArtinApp() }
    }
}

@Composable
fun ArtinApp() {
    val sections = listOf(
        "پرونده خودروهای ایرانی و چینی",
        "دیاگ و پارامترهای زنده",
        "کدهای خطای OBD-II",
        "تعمیرات تخصصی ECU",
        "سیستم مالتی‌پلکس و شبکه CAN / LIN",
        "نقشه سیم‌کشی، سوکت‌ها و پایه‌ها",
        "سنسورها، عملگرها، فیوز و رله",
        "جدول عیب‌یابی و رفع عیب"
    )
    var selected by remember { mutableStateOf("صفحه اصلی") }
    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("ARTIN KHODRO", fontWeight = FontWeight.Bold) })
        }) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("سامانه تخصصی آموزش و تعمیرات خودرو", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("نسخه 1.0.4 — پوسته اولیه قابل توسعه")
                    Spacer(Modifier.height(12.dp))
                }
                items(sections) { section ->
                    Card(onClick = { selected = section }, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(section, fontWeight = FontWeight.SemiBold)
                            if (selected == section) {
                                Spacer(Modifier.height(8.dp))
                                Text("این بخش برای افزودن محتوای فنی تأییدشده و اطلاعات اختصاصی هر مدل آماده است.")
                            }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("هشدار فنی: نقشه پایه‌ها، رنگ سیم‌ها و مقادیر تست باید با سال ساخت، کد موتور و شماره فنی همان خودرو تطبیق داده شوند.")
                }
            }
        }
    }
}
