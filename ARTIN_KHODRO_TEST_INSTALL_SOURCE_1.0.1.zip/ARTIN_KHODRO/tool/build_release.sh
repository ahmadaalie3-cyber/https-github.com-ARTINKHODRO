#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v gradle >/dev/null 2>&1 && [[ ! -x ./gradlew ]]; then
  echo "Gradle/Gradle Wrapper is unavailable. Open this project in Android Studio and sync Gradle first." >&2
  exit 2
fi
if [[ -x ./gradlew ]]; then
  ./gradlew clean test assembleRelease
else
  gradle clean test assembleRelease
fi
echo "APK output: app/build/outputs/apk/release/app-release.apk"
