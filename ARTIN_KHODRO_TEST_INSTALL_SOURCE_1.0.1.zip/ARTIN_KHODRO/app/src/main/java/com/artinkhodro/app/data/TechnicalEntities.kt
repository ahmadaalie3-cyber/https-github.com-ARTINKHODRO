package com.artinkhodro.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "technical_documents")
data class TechnicalDocument(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titleFa: String,
    val category: String,
    val brand: String = "",
    val model: String = "",
    val assetPath: String = "",
    val sourceName: String = "",
    val permissionStatus: String = "needs_review",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "fault_codes", indices = [Index(value = ["code"])])
data class FaultCode(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val titleFa: String,
    val descriptionFa: String = "",
    val possibleCausesFa: String = "",
    val diagnosticStepsFa: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "ecu_catalog")
data class EcuRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val manufacturer: String,
    val family: String,
    val ecuType: String = "",
    val hardwareReference: String = "",
    val softwareReference: String = "",
    val verificationStatus: String = "needs_review"
)

@Entity(tableName = "repair_records")
data class RepairRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleLabel: String = "",
    val ecuHardware: String = "",
    val symptomFa: String,
    val diagnosisFa: String = "",
    val repairActionFa: String = "",
    val repairStatus: String = "received",
    val createdAt: Long = System.currentTimeMillis()
)
