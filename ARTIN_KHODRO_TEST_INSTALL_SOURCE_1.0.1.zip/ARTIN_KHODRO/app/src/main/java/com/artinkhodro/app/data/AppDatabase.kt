package com.artinkhodro.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Vehicle::class, TechnicalDocument::class, FaultCode::class, EcuRecord::class, RepairRecord::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun vehicleDao(): VehicleDao
    abstract fun technicalDao(): TechnicalDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS technical_documents (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, titleFa TEXT NOT NULL, category TEXT NOT NULL, brand TEXT NOT NULL, model TEXT NOT NULL, assetPath TEXT NOT NULL, sourceName TEXT NOT NULL, permissionStatus TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS fault_codes (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, code TEXT NOT NULL, titleFa TEXT NOT NULL, descriptionFa TEXT NOT NULL, possibleCausesFa TEXT NOT NULL, diagnosticStepsFa TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_fault_codes_code ON fault_codes(code)")
                db.execSQL("CREATE TABLE IF NOT EXISTS ecu_catalog (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, manufacturer TEXT NOT NULL, family TEXT NOT NULL, ecuType TEXT NOT NULL, hardwareReference TEXT NOT NULL, softwareReference TEXT NOT NULL, verificationStatus TEXT NOT NULL)")
                db.execSQL("CREATE TABLE IF NOT EXISTS repair_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleLabel TEXT NOT NULL, ecuHardware TEXT NOT NULL, symptomFa TEXT NOT NULL, diagnosisFa TEXT NOT NULL, repairActionFa TEXT NOT NULL, repairStatus TEXT NOT NULL, createdAt INTEGER NOT NULL)")
            }
        }

        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "artin_khodro.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
    }
}
