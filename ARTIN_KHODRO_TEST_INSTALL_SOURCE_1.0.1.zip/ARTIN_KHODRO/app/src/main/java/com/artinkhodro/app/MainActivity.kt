package com.artinkhodro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.artinkhodro.app.data.AppDatabase
import com.artinkhodro.app.data.Vehicle
import com.artinkhodro.app.data.VehicleDao
import com.artinkhodro.app.data.TechnicalDao
import kotlinx.coroutines.launch

private val Black = Color(0xFF101114)
private val Panel = Color(0xFF1C1E23)
private val Gold = Color(0xFFD6AD55)
private val Soft = Color(0xFFE8E5DE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = AppDatabase.get(this)
        setContent { ArtinApp(database.vehicleDao(), database.technicalDao()) }
    }
}

private data class NavItem(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ArtinApp(vehicleDao: VehicleDao, technicalDao: TechnicalDao) {
    var selected by remember { mutableStateOf("خانه") }
    var showAddVehicle by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val navItems = listOf(
        NavItem("خانه", Icons.Default.Home),
        NavItem("خودروها", Icons.Default.DirectionsCar),
        NavItem("آموزش", Icons.Default.MenuBook),
        NavItem("عیب‌یابی", Icons.Default.Build),
        NavItem("مستندات", Icons.Default.Folder)
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Black, surface = Panel)) {
            Scaffold(
                containerColor = Black,
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text("ARTIN KHODRO", color = Gold, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                                Text("مرجع تخصصی آموزش و تعمیرات خودرو", color = Soft, fontSize = 11.sp)
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = Black)
                    )
                },
                bottomBar = {
                    NavigationBar(containerColor = Panel) {
                        navItems.forEach { item ->
                            NavigationBarItem(
                                selected = selected == item.title,
                                onClick = { selected = item.title },
                                icon = { Icon(item.icon, contentDescription = item.title) },
                                label = { Text(item.title, fontSize = 10.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Gold,
                                    selectedTextColor = Gold,
                                    indicatorColor = Black,
                                    unselectedTextColor = Soft
                                )
                            )
                        }
                    }
                }
            ) { padding ->
                when (selected) {
                    "خودروها" -> VehicleScreen(vehicleDao, Modifier.padding(padding), { showAddVehicle = true })
                    "آموزش" -> TrainingScreen(Modifier.padding(padding))
                    "عیب‌یابی" -> DiagnosisScreen(technicalDao, Modifier.padding(padding))
                    "مستندات" -> DocumentsScreen(technicalDao, Modifier.padding(padding))
                    else -> HomeScreen(
                        modifier = Modifier.padding(padding),
                        onVehicles = { selected = "خودروها" },
                        onTraining = { selected = "آموزش" },
                        onDiagnosis = { selected = "عیب‌یابی" },
                        onDocuments = { selected = "مستندات" }
                    )
                }
            }
            if (showAddVehicle) {
                AddVehicleDialog(
                    onDismiss = { showAddVehicle = false },
                    onSave = { make, model, year ->
                        scope.launch {
                            vehicleDao.insert(Vehicle(make = make, model = model, yearFrom = year))
                        }
                        showAddVehicle = false
                    }
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    onVehicles: () -> Unit,
    onTraining: () -> Unit,
    onDiagnosis: () -> Unit,
    onDocuments: () -> Unit
) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.artin_logo),
                    contentDescription = "نشان آرتین خودرو",
                    modifier = Modifier.fillMaxWidth().height(210.dp),
                    contentScale = ContentScale.Fit
                )
                Text("دانش فنی، عیب‌یابی دقیق، تعمیر اصولی", color = Soft, fontSize = 12.sp)
            }
        }
        Text("دسترسی سریع", color = Soft, fontWeight = FontWeight.Bold)
        MenuCard("پرونده خودروها", "ثبت و جست‌وجوی خودروها", Icons.Default.DirectionsCar, onVehicles)
        MenuCard("آموزش تخصصی", "برق خودرو، سنسورها و ECU", Icons.Default.MenuBook, onTraining)
        MenuCard("عیب‌یابی و ECU", "بانک خطاها و اطلاعات تعمیراتی", Icons.Default.Build, onDiagnosis)
        MenuCard("نقشه و مستندات", "کتابخانه آفلاین مستندات فنی", Icons.Default.Folder, onDocuments)
        Text("اطلاعات فنی وابسته به تیپ و شماره سخت‌افزار باید با منبع معتبر تطبیق داده شوند.", color = Gold, fontSize = 12.sp)
    }
}

@Composable
private fun MenuCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Card(onClick = action, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Gold, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Soft, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color.LightGray, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Gold)
        }
    }
}

@Composable
private fun VehicleScreen(dao: VehicleDao, modifier: Modifier, onAdd: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val vehicles by (if (query.isBlank()) dao.observeAll() else dao.search(query)).collectAsState(initial = emptyList())
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("جست‌وجوی خودرو") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("پرونده خودروها", color = Soft, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black)) { Icon(Icons.Default.Add, null); Text("افزودن") }
        }
        if (vehicles.isEmpty()) EmptyState("خودرویی ثبت نشده است. برای شروع از افزودن استفاده کنید.")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vehicles, key = { it.id }) { vehicle ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Text("${vehicle.make} ${vehicle.model}", color = Gold, fontWeight = FontWeight.Bold)
                        Text("سال: ${vehicle.yearFrom ?: "نامشخص"} تا ${vehicle.yearTo ?: "نامشخص"} | موتور: ${vehicle.engine.ifBlank { "ثبت نشده" }}", color = Soft, fontSize = 12.sp)
                        if (vehicle.ecu.isNotBlank()) Text("ECU: ${vehicle.ecu}", color = Soft, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun AddVehicleDialog(onDismiss: () -> Unit, onSave: (String, String, Int?) -> Unit) {
    var make by remember { mutableStateOf("") }
    var model by remember { mutableStateOf("") }
    var year by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ثبت خودرو") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(make, { make = it }, label = { Text("سازنده") }, singleLine = true)
                OutlinedTextField(model, { model = it }, label = { Text("مدل خودرو") }, singleLine = true)
                OutlinedTextField(year, { year = it.filter(Char::isDigit) }, label = { Text("سال ساخت (اختیاری)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = {
            val normalizedYear = year.map { ch ->
                when (ch) {
                    '۰' -> '0'; '۱' -> '1'; '۲' -> '2'; '۳' -> '3'; '۴' -> '4'
                    '۵' -> '5'; '۶' -> '6'; '۷' -> '7'; '۸' -> '8'; '۹' -> '9'
                    '٠' -> '0'; '١' -> '1'; '٢' -> '2'; '٣' -> '3'; '٤' -> '4'
                    '٥' -> '5'; '٦' -> '6'; '٧' -> '7'; '٨' -> '8'; '٩' -> '9'
                    else -> ch
                }
            }.joinToString("")
            if (make.isNotBlank() && model.isNotBlank()) onSave(make.trim(), model.trim(), normalizedYear.toIntOrNull())
        }) { Text("ذخیره", color = Gold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}

@Composable
private fun TrainingScreen(modifier: Modifier = Modifier) {
    val topics = listOf(
        "مبانی برق خودرو و نقشه‌خوانی",
        "سیستم انژکتوری و مدیریت موتور",
        "شناخت سنسورها و عملگرها",
        "تست مدار با مولتی‌متر و اسیلوسکوپ",
        "ساختار ECU و عیب‌یابی برد",
        "شبکه‌های CAN و LIN و مالتی‌پلکس",
        "سیستم ABS، ESP و ایربگ",
        "گیربکس اتوماتیک و TCU",
        "ایموبیلایزر و کلید هوشمند؛ عیب‌یابی مجاز",
        "ایمنی خودروهای هیبریدی و برقی"
    )
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("آموزش تخصصی", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        Text("سرفصل‌های آموزشی برنامه", color = Soft, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(topics) { topic ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, null, tint = Gold)
                        Spacer(Modifier.width(12.dp))
                        Text(topic, color = Soft)
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosisScreen(dao: TechnicalDao, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    val codes by dao.searchFaultCodes(query).collectAsState(initial = emptyList())
    val ecus by dao.searchEcus(query).collectAsState(initial = emptyList())
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("عیب‌یابی و بانک ECU", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("کد خطا، سازنده یا خانواده ECU") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Text("کدهای خطا", color = Soft, fontWeight = FontWeight.Bold)
        if (codes.isEmpty()) Text("هنوز بانک DTC در این نسخه داده تأییدشده ندارد.", color = Color.LightGray, fontSize = 12.sp)
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(codes) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("${item.code} — ${item.titleFa}", color = Gold, fontWeight = FontWeight.Bold)
                        Text(item.descriptionFa.ifBlank { "شرح تکمیلی ثبت نشده" }, color = Soft, fontSize = 12.sp)
                        Text("وضعیت: ${item.verificationStatus}", color = Color.LightGray, fontSize = 10.sp)
                    }
                }
            }
            items(ecus) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Column(Modifier.fillMaxWidth().padding(12.dp)) {
                        Text("${item.manufacturer} — ${item.family}", color = Gold, fontWeight = FontWeight.Bold)
                        Text(item.hardwareReference.ifBlank { "شماره سخت‌افزار ثبت نشده" }, color = Soft, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DocumentsScreen(dao: TechnicalDao, modifier: Modifier = Modifier) {
    var query by remember { mutableStateOf("") }
    val documents by (if (query.isBlank()) dao.observeDocuments() else dao.searchDocuments(query)).collectAsState(initial = emptyList())
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("نقشه و مستندات", color = Gold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), label = { Text("جست‌وجوی مستند") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        if (documents.isEmpty()) {
            EmptyState("مستندات هنوز به بانک برنامه وارد نشده‌اند. فقط فایل‌های مجاز و تأییدشده باید به نسخه آفلاین افزوده شوند.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(documents) { doc ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(doc.titleFa, color = Gold, fontWeight = FontWeight.Bold)
                            Text("${doc.category} | ${doc.brand} ${doc.model}", color = Soft, fontSize = 12.sp)
                            Text("اعتبار: ${doc.verificationStatus} | مجوز: ${doc.permissionStatus}", color = Color.LightGray, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Text(message, color = Soft, modifier = Modifier.fillMaxWidth().padding(18.dp), fontSize = 13.sp)
    }
}
