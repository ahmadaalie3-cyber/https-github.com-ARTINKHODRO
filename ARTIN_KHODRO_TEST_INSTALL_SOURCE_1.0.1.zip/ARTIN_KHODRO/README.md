# ARTIN KHODRO — Android project

Persian RTL offline-first automotive electrical and diagnostics app starter.

- Native Android: Kotlin + Jetpack Compose
- Local database: Room / SQLite
- App ID: `com.artinkhodro.app`
- minSdk 24 / targetSdk 35
- Black / gold visual theme

See `docs/PROJECT_STATUS_FA.md` for build instructions, included modules, and known limitations.

**Important:** this is a source project package, not a compiled or device-tested APK. Vehicle-specific technical values and proprietary documents must be verified and licensed before release.

Security note: Android backup and cleartext traffic are disabled in the manifest. This is only baseline hardening. App-level PIN/biometric lock, database encryption, integrity checks, release signing, and device security testing are not yet implemented. Do not describe this build as hack-proof or production-ready.
